simple-upload
=============

Simple image upload with Express
